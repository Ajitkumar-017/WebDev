/** @type {import('tailwindcss').Config} */
module.exports = {
  prefix: 'tw-',
  content: [],
  theme: {
    extend: {},
  },
  plugins: [],
}

