document.addEventListener("DOMContentLoaded", function() {
    // Retrieve the form element
    const form = document.querySelector("form");

    // Add submit event listener to the form
    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the default form submission behavior

        // Get form values
        const email = form.email.value;
        const password = form.psw.value;
        const repeatPassword = form['psw-repeat'].value;

        // Check if passwords match
        if (password !== repeatPassword) {
            alert("Passwords do not match!");
            return;
        }

        // Store user information in localStorage
        localStorage.setItem("email", email);
        localStorage.setItem("password", password);

        // Redirect or perform any necessary action after successful login/signup
        // For now, let's just log a message
        console.log("User signed up/login successfully!");
    });
});
